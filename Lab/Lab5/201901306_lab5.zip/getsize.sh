#!/bin/bash

				#she bang line
if [ $# -eq 0 ]; then
	echo ERROR: Require file		# Here "$#" counts the total number of parameters used.If number of parameters = 0,it gives an error.
	exit 1
fi

				
if [ -f $1 ]                         # Here,$1 takes the first parameter and -f is used to check if the first parameter is a file or not. 
then 
	echo `wc -c $1 | cut d " "-f 1` 	#If the first parameter is a file,it will give the size of that file
elif [ -d $1 ] 				# Here,$1 takes the first parameter and -d is used to check if first parameter is directory or not
then
echo `ls -sh $1 | head -1 | cut -d " " -f 2`  #if first parameter is a directory,it will give the size of that directory
else
echo ERROR : $1 does not exist        #If a file/directory does not exist ,it will give this type of error
fi

#In the above code,the command line `wc -c $1 | cut d " "-f 1` is used to get the size of #the file by counting the bytes of the file by using wc and cut the first field which is #size of that file.

#In the above code,the command line `ls -sh $1 | head -1 | cut -d " " -f 2` is used to get #the size of the directory and here the command -sh gives the size of the directory 
# which can be read by humans,then get the first and cut the second field which eventually #is the size of that directory.