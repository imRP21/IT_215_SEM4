#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <string.h>

int main(int argc,char *argv[])
{
        int n=argc-2; //From the argc number of inputs argc-2 numbers are of the array from 1 to argc-2
        int arr[n];
        //Creating array from command line inputs
        for(int i=0;i<n;i++)
        	arr[i]=atoi(argv[i+1]);
        //Bubble Sort Algorithm
        for(int i=0;i<n;i++)
        {
        	for(int j=0;j<n-i-1;j++)
        	{
        		if(arr[j]>arr[j+1])
        		{
        			int temp=arr[j];
        			arr[j]=arr[j+1];
        			arr[j+1]=temp;
        		}
        	}
        }
        // Creating string array to pass as a command line argument to the Child process.
        char *arr2[n+2];

        //Allocating the integers to the string array using the snprintf() and malloc function.
        for(int i=0;i<n;i++)
        {
        	char a[sizeof(int)];
        	snprintf(a,sizeof(int),"%d",arr[i]);
        	arr2[i]=malloc(sizeof(a)); //Allocates size to the ith string
        	strcpy(arr2[i],a); //copies the integer at the end of the string
        }
        //last number is the number that is to be searched
        arr2[n]=argv[argc-1];
        arr2[n+1]=NULL; //The argument vector must end with NULL.
        if(fork()==0)  //Creates a Child process.
        {
        	execv("child",arr2); //Calls the execv() system call. The sorted array is passed as an argument.
        }
        wait(NULL);  //Parent process waits for the Child process to terminate.
        return 0;
}
