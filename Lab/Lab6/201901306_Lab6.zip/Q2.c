#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <signal.h>

int main(int argc,char *argv[])
{
	//1st child is created
        if(fork()==0)
        {
        	//cp command is executed using the execlp() system call
        	execlp("cp","cp",argv[1],argv[2],NULL);
        	printf("Error executing cp\n");
        }
        else
        {
        	//Untill cp command is executed, parent will wait.
        	wait(NULL);
        	//2nd child is created
        	if(fork()==0)
        	{
        		//sort command is executed using execlp() system call
        		execlp("sort","sort",argv[3],"-o",argv[4],NULL);
        		printf("Error executing sort\n");
        	}
        	else
        	{
        		// Parent waits for 2nd child to complete its process.
        		wait(NULL);
        		//3rd child is created
        		if(fork()==0)
        		{
				//cat command is executed using execlp() system call.
        			execlp("cat","cat",argv[4],NULL);
        			printf("Error executing cat\n");
        		}
        		else
        		//Parent waits for 3rd child to complete its process.
        			wait(NULL);
        	}
        }
        return 0;
}
