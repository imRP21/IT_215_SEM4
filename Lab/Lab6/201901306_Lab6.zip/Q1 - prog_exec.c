#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <signal.h>

int main(int argc,char *argv[])  //Taking input using command line arguments
{
	if(argc==1 || argc>2)
	{
		printf("Usage: ./prog_exec command\n");
		return 0;
	}
        if(fork()==0)   //Creating a child using fork() system call
        {
        	if(execv(argv[1],argv+1)==-1)  //Calling execv()
        	{
        		perror(argv[1]);  //Printing error if not executed successfully
        		exit(1);          //exit with non zero value
        	}
        	else
        	{
        		exit(0);          //exit with 0 value
        	}
        }
        int status;
        int stat=wait(&status);    //Calling wait()
        int e=WEXITSTATUS(status); //Storing exit status of Child

        //If condition for printing whether executed succesfully or not
        if(e==0)
        	printf("Process %d succeeded.\n",stat);
        else
        	printf("Process %d exited with an error value: %d\n",stat,e);
        return 0;
}
