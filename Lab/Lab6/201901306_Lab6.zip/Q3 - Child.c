#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <signal.h>
#include <string.h>

int main(int argc, char *argv[])
{
	int n=argc-2;
	int arr[n];
	//Generates integer array from string
	for(int i=0;i<n;i++)
		arr[i]=atoi(argv[i+1]);
	// Binary search Algorithm
	int left=0,right=n-1;
	int temp=atoi(argv[argc-1]);
	int ans=-1;
	while(left<=right)
	{
		int mid=(left+right)/2;
		if(arr[mid]==temp)
		{
			ans=arr[mid];
			break;
		}
		else if(arr[mid]>temp)
			right=mid-1;
		else
			left=mid+1;

	}
	//If ans is -1 then the number is not found
	if(ans==-1)
		printf("Not found\n");
	else //else Number is found and it is printed
		printf("Found %d.\n",ans);
	return 0;
}
