#include <unistd.h>
#include <sys/types.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <signal.h>

main()
{
    pid_t pid;
    char cmd[20];
    pid = getpid();
    
    //first and second fork calls
    if (fork() == 0)
    {
        if (fork() == 0)
            while(1);
        while(1);
    }
    
    //third and fourth fork calls
    if (fork() == 0)
    {
        if (fork() == 0)
            while(1);
            
        /*below conditional statements which are commented were generating 2 children both going
        into infinite loops. If we skip that part we are to generate 2 children thereby generating
        the same process heirarchy with exactly 5 fork calls*/
        
        // if (fork() == 0)
        //     while(1);
        // while(1);
    }
    
    //fifth fork call
    if (fork() == 0)
        while(1);
    
    getc(stdin);
    sprintf(cmd, "pstree -p %d\n", pid);
    system(cmd);
    kill(pid, SIGKILL);
}