#include <unistd.h>
#include <sys/types.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <signal.h>

main()
{
    pid_t pid;
    char cmd[20];
    pid = getpid();
    
    int flag=0;
    //first fork call
    if (fork() == 0)
        flag=1;
        //this flag will prevent the first child of parent to go into the next code
    
    //second and third fork calls
    if (flag==0 && fork() == 0)
    {
        if (fork() == 0)
            while(1);
        
        //2nd child of the main parent will be created and its 2 children are also generated. 
    }
    
    //fourth fork call
    //in this fork call 2 children of every open end is generated thus giving the same process heirarchy
    if (fork() == 0)
        while(1);
    
    getc(stdin);
    sprintf(cmd, "pstree -p %d\n", pid);
    system(cmd);
    kill(pid, SIGKILL);
}