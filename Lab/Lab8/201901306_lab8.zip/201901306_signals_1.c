#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <signal.h>
#include <unistd.h>

//Declaring a File pointer
FILE *file_ptr;

//Alarm Handler
//It prints that it took too long to enter the file and append the same in the file. 
void alarm_fn()
{
	fputs("It took too long to enter the string\n", file_ptr);
    puts("It took too long to enter the string");
    fclose(file_ptr); //Close the file
    
    exit(-1); //return -1
}

int main()
{
    //Opens the file in append mode and stores the pointer position in fptr.
    file_ptr=fopen("201901306_signals_1.txt","a");
    
    if(file_ptr==NULL) //file can't be opened with a null ptr.
        printf("File not opened successfully\n"); 

    //Set the signal handler by calling alarm_setter
    signal(SIGALRM,alarm_fn);

    char message[100];
    printf("Enter a string: ");
    
    alarm(10); //Alarm time = 10s
    scanf("%s",message); //Take input string
	printf("Entered string: %s\n\n",message);
    
    fprintf(file_ptr,"Entered string: %s\n",message);
    fclose(file_ptr);
    
    return 0;
}
