#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <signal.h>

//Declaring a File pointer
FILE *file_ptr;

void signal_handler()
{
    file_ptr = fopen("201901306_signals_3.txt","a");
    
    if(file_ptr == NULL)
    {
        fprintf(stderr, "Error opening file"); //print error if file ptr is null
        exit(1);
    }
    printf("Process id %d received SIGINT signal\n", getpid());
    //Print output
    fprintf(file_ptr, "Process id %d received SIGINT signal\n", getpid());
    fclose(file_ptr); //close file

}

int main()
{
    //Defining a signal handler for SIGINT
    signal(SIGINT, signal_handler);

    if(!fork())
    {
        //Printing process ID and Process group ID of Child Process
        file_ptr = fopen("201901306_signals_3.txt", "a");
        if(file_ptr == NULL)
        {
            fprintf(stderr, "Error opening file");
            exit(1);
        }
        setpgid(0, getpid());//Child Process Group ID is set to its process ID.
        printf("Child PID: %d and Child Process Group ID: %d\n", getpid(), getpgid(0));
        fprintf(file_ptr, "Child PID: %d and Child Process Group ID: %d\n", getpid(), getpgid(0));
        fclose(file_ptr);
    }
    else
    {
        //Printing Process ID and Process Group ID of Parent
        file_ptr = fopen("201901306_signals_3.txt", "a");
        if(file_ptr == NULL)
        {
            fprintf(stderr, "Error opening file");
            exit(1);
        }
        printf("Parent PID: %d and Parent Process Group ID: %d\n", getpid(), getpgid(0));
        fprintf(file_ptr,"Parent PID: %d and Parent Process Group ID: %d\n", getpid(), getpgid(0));
        fclose(file_ptr);
    }
    pause();
}

