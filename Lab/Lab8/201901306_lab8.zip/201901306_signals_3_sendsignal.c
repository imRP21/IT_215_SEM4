#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <signal.h>
#include <fcntl.h>

//Declaring a File pointer
FILE *file_ptr;

int main()
{
	file_ptr = fopen("201901306_signals_3.txt", "a");

    if(file_ptr < 0) //unable to open file
        printf("Error opening file\n");

    int pid, value;
    char *s1 = "Process ID of the process to which you need to send the signal to: ";
    char *s2 = "Send signal to process(1) or Process group(2): ";
    printf("%s", s1);
    scanf("%d", &pid); puts("");
    printf("%s", s2);
    scanf("%d", &value); puts("");

    fprintf(file_ptr, "Process ID of the process to which you need to send the signal to: %d\n", pid);
    fprintf(file_ptr, "Send signal to process(1) or Process group(2): %d\n", value);

    //If value=1 then only that particular process ID terminates
	if(value == 1)
        kill(pid, SIGINT);
    else //If value=2 then the whole process group gets SIGINT signal
        kill(-pid, SIGINT);

    return 0;
}

