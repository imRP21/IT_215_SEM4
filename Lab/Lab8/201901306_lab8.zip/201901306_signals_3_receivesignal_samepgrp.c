#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <signal.h>

//Declaring a File pointer
FILE *file_ptr;
        
void signal_handler()
{
    file_ptr = fopen("201901306_signals_3.txt", "a");
    if(file_ptr == NULL)
    {
        fprintf(stderr, "Error opening file");
        exit(1);
    }
    //Printing process ID in file and terminal
    printf("Process id %d received SIGINT signal\n", getpid());
    fprintf(file_ptr, "Process id %d received SIGINT signal\n", getpid());
    fclose(file_ptr);

}

int main()
{
    signal(SIGINT, signal_handler);

    if(!fork())
    {
        //Printing Process ID and Process group ID of Child Process
        file_ptr = fopen("201901306_signals_3.txt","a");
        if(file_ptr == NULL)
        {
            fprintf(stderr, "Error opening file");
            exit(1);
        }
        printf("Child PID: %d and Child Process Group ID: %d\n", getpid(), getpgid(0));
        fprintf(file_ptr, "Child PID: %d and Child Process Group ID: %d\n", getpid(), getpgid(0));
        fclose(file_ptr);
    }
    else
    {
        //Printing Process ID and Process group ID of Parent process
        file_ptr = fopen("201901306_signals_3.txt", "a");
        if(file_ptr == NULL)
        {
            fprintf(stderr, "Error opening file");
            exit(1);
        }
        printf("Parent PID: %d and Parent Process Group ID: %d\n", getpid(), getpgid(0));
        fprintf(file_ptr, "Parent PID: %d and Parent Process Group ID: %d\n", getpid(), getpgid(0));
        fclose(file_ptr);
    }
    pause();
}

