#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <fcntl.h>

#define READ 0
#define WRITE 1
#define MSGLEN 100

int main()
{

    //Array of Questions.
    char* questions[] = {"Quit", "In which university do you study?", "Which course are you studying?", "What is your area of interest?"};
    
    //Printing the Questions.
    for(int i = 0; i < 4; i++)
        printf("Question %d : %s\n", i, questions[i]);
	puts("");
	
    //Creating File Pointer
    FILE *fPtr;
	fPtr = fopen("201901306_pipes.txt", "w");
	fclose(fPtr);
	
	
    while(1)
    {
    	//Two pipes for Bidirectional Communication, Parent Process <-> Child Process.
        int fd1[2];     //For Unidirectional Communication, Parent Process -> Child Process.
        int fd2[2];     //For Unidirectional Communication, Child Process -> Parent Process.

		//Return value of pipe function calls are stored in status1 and status2.
        int status1 = pipe(fd1);
        int status2 = pipe(fd2);
        
        //Gives error if Pipe is not created successfully.
        if(status1 == -1 || status2 == -1)
        {
            fputs("Pipe Operation Failed", stderr);
            return 1;
        }

        //Pointer to the file is stored in oldfd. 
        //"O_WRONLY | O_APPEND" - to open the file in - write and append mode.
        int oldfd = open("201901306_pipes.txt", O_WRONLY | O_APPEND);
        
		if(oldfd < 0)
            puts("Error opening the file");

    	if(!fork())    //Child Process
       	{
            close(fd1[WRITE]);   //Close Write for Parent -> Child Pipe - fd1.
			close(fd2[READ]);    //Close Read for Child -> Parent Pipe - fd2.
			
            //Array of Answers.
            char* answers[] = {"Quit", "DAIICT", "Systems Software", "Kernel Programming"};
            char message[100];

            //Child Process reads the question received from the Parent process through Parent -> Child Pipe - fd1.
            int bytesRead = read(fd1[READ], message, MSGLEN);

            if(!strcmp(message, "Quit"))    //If Question is "Quit".
                write(fd2[WRITE], answers[0], strlen(answers[0]) + 1);
                
            else
                for(int i = 0;i < 4; i++)   //Finding the index of Question in the question string array.
                    if(!strcmp(questions[i], message))
                    {
                        //Child Process writes the answer of received question in Child -> Parent - fd2.
                        write(fd2[WRITE], answers[i], strlen(answers[i]) + 1);

                        //Appending in the file
                        char *newstr = malloc(strlen(message) + 2);
                        strcpy(newstr, message);
                        strcat(newstr, "\n");
                        write(oldfd, newstr, strlen(newstr));
                        break;
                    }

            close(fd1[READ]);   //Close Read for Parent -> Child Pipe - fd1.
            close(fd2[WRITE]);  //Close Write for Child -> Parent Pipe - fd2.

            exit(0);
       	}
       	else
       	{
            close(fd1[READ]); 	//Close Read for Parent -> Child Pipe - fd1.
			//We'll Close Write for Child -> Parent Pipe - fd2, after the execution of Child Process, i.e., after the wait() call.
				
            char message[100];  //String for storing answer.
            int Que;   			//Question number

            printf("Enter question number: ");
            scanf("%d", &Que);

            if(Que < 0 || Que > 3)  //0 <= Que <= 3
            {
				puts("Invalid Question Number\n");
                continue;
            }

            //Writing in the Parent -> Child Pipe - fd1.
            write(fd1[WRITE], questions[Que], strlen(questions[Que]) + 1);

            //Waiting for the Child process to complete the exection.
            wait(NULL);
            
            close(fd2[WRITE]);	//Close Write for Child -> Parent Pipe - fd2.

            //Reading the answer received from the Child Process
            int bytesRead = read(fd2[READ], message, MSGLEN);
			
            printf("Answer: %s\n\n", message);
            if(!strcmp(message, "Quit"))   //If "Quit"
            {
                close(fd1[READ]);
                close(fd1[WRITE]);
                close(fd2[READ]);
                close(fd2[WRITE]);
                close(oldfd);
				return 0;
            }

			close(fd1[WRITE]); 	//Close Write for Parent -> Child Pipe - fd1.
            close(fd2[READ]);	//Close Read for Child -> Parent Pipe - fd2.
			
			strcat(message, "\n\n");	

            //Appending in the file.
            write(oldfd, message, strlen(message));
        }
    }
    return 0;
}
